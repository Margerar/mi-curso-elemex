﻿define a = Character("Ana")

define l = Character("Luis")

transform fondo_ajustado:

    xysize (1920, 1080)

transform personaje_centro:

    zoom 0.55

    xalign 0.5

    yalign 1.0

transform personaje_izquierda:

    zoom 0.50

    xalign 0.25

    yalign 1.0

transform personaje_derecha:

    zoom 0.50

    xalign 0.75

    yalign 1.0

label start:

    # ESCENA 1 — LLEGADA A LA UNIVERSIDAD

    scene bg_salon at fondo_ajustado

    show ana_normal at personaje_centro

    a "¡Hola! Bienvenido a tu primer día en una universidad mexicana."

    a "Hoy practicarás frases útiles para pedir ayuda, encontrar tu salón y hablar con otros estudiantes."

    hide ana_normal

    show ana_feliz at personaje_centro

    a "¡No te preocupes! Vamos paso a paso."

    # ESCENA 2 — CONOCER A UN COMPAÑERO

    scene bg_calle_mexico at fondo_ajustado

    show luis_normal at personaje_centro

    l "En México es común hablar con otros estudiantes de manera cercana e informal."

    l "Si no sabes dónde está tu clase, puedes decir: “Disculpa, ¿en qué salón es la clase?”"

    l "También puedes pedir ayuda con una frase sencilla: “¿Me puedes ayudar?”"

    hide luis_normal

    show luis_feliz at personaje_centro

    l "¡Así puedes empezar una conversación sin problema!"

    # ESCENA 3 — VOCABULARIO UNIVERSITARIO

    scene bg_salon at fondo_ajustado

    show ana_normal at personaje_izquierda

    show luis_normal at personaje_derecha

    a "Repasemos vocabulario útil para la universidad."

    l "“Salón” significa aula o classroom."

    a "“Horario” es tu schedule."

    l "“Tarea” significa homework."

    a "Y “cafetería” es el lugar donde puedes comer o tomar algo entre clases."

    # ESCENA 4 — EXPRESIONES DE ESTUDIANTES

    scene bg_cafeteria at fondo_ajustado

    show ana_normal at personaje_izquierda

    show luis_normal at personaje_derecha

    l "Entre estudiantes también escucharás expresiones mexicanas."

    a "Por ejemplo: “¿Tienes apuntes?”"

    l "Eso significa: ¿tienes tus notas de clase?"

    a "También puedes decir: “Voy un poco perdido/a” cuando no entiendes bien dónde estás o qué debes hacer."

    # ESCENA 5 — PREGUNTA INTERACTIVA

    scene bg_salon at fondo_ajustado

    show ana_normal at personaje_izquierda

    show luis_normal at personaje_derecha

    a "Ahora imagina esta situación."

    l "Llegas tarde a la universidad y no sabes dónde está tu clase."

    a "Necesitas pedir ayuda a un compañero mexicano."

    l "¿Qué frase usarías?"

    menu:

        "Disculpa, ¿en qué salón es la clase?":

            jump correcta

        "Dame tu tarea ahora mismo.":

            jump incorrecta

        "No quiero hablar con nadie.":

            jump incorrecta

# RESULTADO CORRECTO

label correcta:

    scene bg_salon at fondo_ajustado

    show ana_feliz at personaje_izquierda

    show luis_feliz at personaje_derecha

    a "¡Correcto!"

    l "“Disculpa, ¿en qué salón es la clase?” es una forma clara y educada de pedir información."

    a "Muy bien. Ya puedes usar esta frase en tu primer día de universidad."

    return

# RESULTADO INCORRECTO

label incorrecta:

    scene bg_salon at fondo_ajustado

    show ana_normal at personaje_izquierda

    show luis_normal at personaje_derecha

    a "Esa opción no es la mejor para esta situación."

    l "Cuando necesitas ayuda, es mejor usar una frase educada como: “Disculpa, ¿en qué salón es la clase?”"

    a "Inténtalo de nuevo y recuerda usar una expresión amable."

    return